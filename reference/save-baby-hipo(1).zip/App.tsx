
import React, { useState, useCallback, useEffect } from 'react';
import Game from './components/Game';
import UIOverlay from './components/UIOverlay';
import { GameState, GameImages } from './types';
import { LEVELS } from './constants';
import { GoogleGenAI } from "@google/genai";

const App: React.FC = () => {
  const [gameState, setGameState] = useState<GameState>(GameState.INITIALIZING);
  const [currentLevelIdx, setCurrentLevelIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [images, setImages] = useState<GameImages | null>(null);
  const [initStatus, setInitStatus] = useState("준비 중...");

  const currentLevel = LEVELS[currentLevelIdx];

  // 하얀색 배경을 투명하게 만드는 함수
  const processImageTransparency = (dataUrl: string): Promise<string> => {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        if (!ctx) return resolve(dataUrl);
        
        ctx.drawImage(img, 0, 0);
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const data = imageData.data;
        
        // 하얀색에 가까운 픽셀(RGB > 240)을 투명하게 처리
        for (let i = 0; i < data.length; i += 4) {
          const r = data[i];
          const g = data[i+1];
          const b = data[i+2];
          if (r > 240 && g > 240 && b > 240) {
            data[i + 3] = 0;
          }
        }
        
        ctx.putImageData(imageData, 0, 0);
        resolve(canvas.toDataURL());
      };
      img.onerror = () => resolve(dataUrl);
      img.src = dataUrl;
    });
  };

  const generateGameAssets = async () => {
    try {
      setInitStatus("아기 하마 그리는 중...");
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const generateImg = async (prompt: string, aspectRatio: "1:1" | "4:3" = "1:1") => {
        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash-image',
          contents: { parts: [{ text: prompt }] },
          config: { imageConfig: { aspectRatio } }
        });
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) return `data:image/png;base64,${part.inlineData.data}`;
        }
        return "";
      };

      // 캐릭터 프롬프트 개선: 명확한 하얀 배경의 스티커 스타일 요청
      const rawHipoImg = await generateImg("Full body of a very cute, chubby, simple 2D cartoon baby hippo, facing forward, high contrast, sticker style with a clean solid white background, flat vector art, vibrant purple tones.");
      setInitStatus("배경 제거 중...");
      const hipoImg = await processImageTransparency(rawHipoImg);

      setInitStatus("굶주린 피라니아 생성 중...");
      const rawPiranhaImg = await generateImg("Small fierce 2D cartoon piranha with sharp teeth, side view, sticker style with a clean solid white background, red and orange gradient, bold outlines, flat vector art.");
      const piranhaImg = await processImageTransparency(rawPiranhaImg);

      setInitStatus("깊은 바닷속 풍경 조성 중...");
      const bgImg = await generateImg("A professional high-quality 2D cartoon underwater background, crystal clear blue water, sand floor, some seaweeds and coral reefs, soft sunrays filtering from top, cinematic lighting, flat illustration style.", "4:3");

      setImages({ hipo: hipoImg, piranha: piranhaImg, background: bgImg });
      setGameState(GameState.START);
    } catch (error) {
      console.error("Image generation failed", error);
      setInitStatus("이미지 생성 실패. 기본 그래픽으로 시작합니다.");
      setGameState(GameState.START);
    }
  };

  useEffect(() => {
    generateGameAssets();
  }, []);

  const handleStart = () => {
    setGameState(GameState.PLAYING);
  };

  const handleWin = useCallback(() => {
    setGameState(GameState.WIN);
    setScore(prev => prev + (currentLevelIdx + 1) * 100);
  }, [currentLevelIdx]);

  const handleLose = useCallback(() => {
    setGameState(GameState.LOSE);
  }, []);

  const nextLevel = () => {
    if (currentLevelIdx < LEVELS.length - 1) {
      setCurrentLevelIdx(prev => prev + 1);
      setGameState(GameState.PLAYING);
    } else {
      setCurrentLevelIdx(0);
      setGameState(GameState.START);
    }
  };

  const restartLevel = () => {
    setGameState(GameState.PLAYING);
  };

  const restartFromBeginning = () => {
    setCurrentLevelIdx(0);
    setScore(0);
    setGameState(GameState.PLAYING);
  };

  if (gameState === GameState.INITIALIZING) {
    return (
      <div className="w-full h-screen flex flex-col items-center justify-center bg-cyan-900 text-white">
        <div className="animate-bounce text-6xl mb-8">🦛</div>
        <h2 className="text-2xl font-bold mb-2">Save Baby Hipo</h2>
        <p className="text-cyan-300 animate-pulse">{initStatus}</p>
        <div className="mt-8 w-64 h-2 bg-white/20 rounded-full overflow-hidden">
            <div className="h-full bg-cyan-400 animate-loading-bar"></div>
        </div>
        <style>{`
          @keyframes loading-bar {
            0% { width: 0%; }
            100% { width: 100%; }
          }
          .animate-loading-bar { animation: loading-bar 5s linear infinite; }
        `}</style>
      </div>
    );
  }

  return (
    <div className="relative w-full h-screen flex flex-col items-center justify-center bg-cyan-100 overflow-hidden select-none">
      <div className="absolute top-4 left-4 z-10 bg-white/80 p-3 rounded-xl shadow-lg border-2 border-cyan-400">
        <h1 className="text-xl font-bold text-cyan-700">레벨 {currentLevelIdx + 1} / 50</h1>
        <p className="text-sm font-semibold text-cyan-600">점수: {score}</p>
      </div>

      <div className="relative shadow-2xl border-8 border-blue-900/20 rounded-2xl overflow-hidden bg-white">
        <Game 
          level={currentLevel} 
          gameState={gameState} 
          setGameState={setGameState}
          onWin={handleWin}
          onLose={handleLose}
          images={images}
        />
        
        <UIOverlay 
          gameState={gameState} 
          onStart={handleStart} 
          onNext={nextLevel} 
          onRestart={restartLevel} 
          onFullReset={restartFromBeginning}
          levelNum={currentLevelIdx + 1}
        />
      </div>

      <div className="mt-6 text-cyan-900 font-medium text-center max-w-md px-4">
        <p className="text-sm opacity-80 mb-2">
          <b>규칙:</b> 잉크가 제한되어 있습니다. 둥지와 힙포 주변에는 선을 그을 수 없습니다.<br/>
          선을 효율적으로 사용하여 모든 방향에서 오는 피라니아를 막으세요!
        </p>
      </div>
    </div>
  );
};

export default App;
